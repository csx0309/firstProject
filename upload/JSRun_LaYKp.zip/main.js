var dropbox = document.getElementById("dropbox");
var inputarea = document.getElementById("inputarea");
var preview = document.getElementById("preview");
var output = document.getElementById("output");

/**
 * 点击输入
 */
inputarea.addEventListener('change', function(event) {
	var files = inputarea.files;
	handle("filelists", files);
}, false);

/**
 * 拖拽实现
 */
dropbox.addEventListener("dragenter", function(e){
	e.stopPropagation();
	e.preventDefault();
}, false);

dropbox.addEventListener("dragover", function(e){
	e.stopPropagation();
	e.preventDefault();
}, false);

dropbox.addEventListener("drop", function(e){
	e.stopPropagation();
	e.preventDefault();

	var dt = e.dataTransfer;
	var files = dt.files;

	handle("filelists", files);
}, false);

/**
 * 复制粘贴
 */
dropbox.addEventListener('paste', function(event){
	// 添加到事件对象中的访问系统剪贴板的接口
	var clipboardData = event.clipboardData, items, item, types;
	if(clipboardData){
		items = clipboardData.items;
		if(!items){
			return;
		}
		item = items[0];
		// 保存在剪贴板中的数据类型
		types = clipboardData.types || [];
		for(var i=0; i < types.length; i++){
			if( types[i] === 'Files'){
				item = items[i];
				break;
			}
		}
		// 判断是否为图片数据
		if(item && item.kind === 'file' && item.type.match(/^image\//i)){
			// 读取该图片          
			var blob = item.getAsFile();
			handle("blob", blob);
		}
	}
});

function handle(type, data){
	// 处理结果
	var handleResult = function(file){
		var img = document.createElement("img");
			img.file = file;
			preview.appendChild(img);

			var reader = new FileReader();
			reader.onload = (function(aImg) { 
				return function(e) { 
					aImg.src = e.target.result; 
					output.innerHTML = e.target.result;				        
				}; 
			})(img);
			reader.readAsDataURL(file);
	}

	if (type === "filelists") {
		var files = data;
		for (var i = 0; i < files.length; i++) {
			var file = files[i];
			var imageType = /^image\//;
			if (!imageType.test(file.type)) {
					continue;
			}  
			handleResult(file);
		}
	} else if (type === "blob") {
		handleResult(data);
	}
}
